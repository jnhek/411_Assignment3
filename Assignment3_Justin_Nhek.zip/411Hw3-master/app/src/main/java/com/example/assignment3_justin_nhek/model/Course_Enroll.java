package com.example.assignment3_justin_nhek.model;

public class Course_Enroll {

    protected String mCourse_Id;
    protected String mCourse_Grade;

    public Course_Enroll(String Course_Id, String Course_Grade) {
        mCourse_Id = Course_Id;
        mCourse_Grade = Course_Grade;
    }

    public String getGrade() {
        return mCourse_Grade;
    }

    public void setGrade(String grade) {
        mCourse_Grade = grade;
    }

    public String getCourseId() {
        return  mCourse_Id;
    }

    public void setCourseId(String courseId) {
        mCourse_Id = courseId;
    }

}
